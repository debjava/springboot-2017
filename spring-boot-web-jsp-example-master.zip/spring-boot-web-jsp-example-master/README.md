Sample Spring Boot Web Application with JSP
====

Building and running
---

    mvn clean spring-boot:run
