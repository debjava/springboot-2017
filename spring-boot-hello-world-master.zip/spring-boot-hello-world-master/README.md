# Sample Spring Boot Application #

This sample Spring Boot application was written for a blog post describing how to create a Spring Boot application with IntelliJ.

http://patrickgrimard.com/2014/08/14/how-to-build-a-spring-boot-application-using-intellij-idea/
