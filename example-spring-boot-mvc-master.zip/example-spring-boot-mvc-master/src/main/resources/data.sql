INSERT INTO user (id, password) VALUES ('user1', 'pass1');
INSERT INTO user (id, password) VALUES ('user2', 'pass1');
INSERT INTO user (id, password) VALUES ('user3', 'pass1');
INSERT INTO user (id, password) VALUES ('user4', 'pass1');